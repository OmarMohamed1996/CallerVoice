package com.omar.callervoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("caller_voice", MODE_PRIVATE) }
    private lateinit var enabled: Switch
    private lateinit var language: Spinner
    private lateinit var repeat: Spinner
    private lateinit var volume: SeekBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 28, 44)
        window.navigationBarColor = Color.rgb(16, 28, 44)
        buildScreen()
        requestNeededPermissions()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(246, 248, 250))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "CALLER VOICE"
            textSize = 27f
            setTextColor(Color.rgb(16, 35, 52))
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Smart Incoming Caller Announcer\nمساعد الإعلان عن اسم المتصل"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 24)
        }
        content.addView(title)
        content.addView(subtitle)

        enabled = Switch(this).apply {
            text = "تفعيل نطق اسم المتصل / Enable caller announcement"
            textSize = 16f
            isChecked = prefs.getBoolean("enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
                updateStatus()
            }
        }
        addSection(content, enabled)

        language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("عربي + English", "العربية فقط", "English only"))
            setSelection(prefs.getInt("language", 0))
            onItemSelectedListener = simpleListener { prefs.edit().putInt("language", it).apply() }
        }
        addLabeledSpinner(content, "لغة الإعلان / Announcement language", language)

        repeat = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("مرة واحدة / Once", "مرتين / Twice"))
            setSelection(prefs.getInt("repeat", 0))
            onItemSelectedListener = simpleListener { prefs.edit().putInt("repeat", it).apply() }
        }
        addLabeledSpinner(content, "تكرار الاسم / Repeat", repeat)

        val volumeLabel = TextView(this).apply { text = "مستوى الصوت / Announcement volume"; textSize = 15f; setTextColor(Color.DKGRAY) }
        volume = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("volume", 85)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) prefs.edit().putInt("volume", value).apply() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        addSection(content, volumeLabel)
        addSection(content, volume)

        val test = Button(this).apply {
            text = "تجربة الصوت / Test voice"
            setOnClickListener { testVoice() }
        }
        addSection(content, test)

        status = TextView(this).apply { textSize = 14f; setPadding(12, 18, 12, 12); setTextColor(Color.rgb(25, 110, 75)) }
        addSection(content, status)

        val permissions = Button(this).apply {
            text = "منح الصلاحيات / Grant permissions"
            setOnClickListener { requestNeededPermissions() }
        }
        addSection(content, permissions)
        val ttsSettings = Button(this).apply {
            text = "إعدادات تحويل النص إلى كلام / TTS settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).also { /* fallback below */ }) }
        }
        // TTS engine settings are device-specific; open general TTS settings when available.
        ttsSettings.setOnClickListener {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        addSection(content, ttsSettings)
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)
        updateStatus()
    }

    private fun addSection(parent: LinearLayout, view: android.view.View) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); setBackgroundColor(Color.WHITE) }
        box.addView(view)
        val params = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = 12
        parent.addView(box, params)
    }

    private fun addLabeledSpinner(parent: LinearLayout, label: String, spinner: Spinner) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, 0, 0, 8) })
        wrap.addView(spinner)
        addSection(parent, wrap)
    }

    private fun simpleListener(action: (Int) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) = action(position)
    }

    private fun requestNeededPermissions() {
        val needed = arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 44)
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val phone = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val callLog = checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED
        val ready = phone && contacts && callLog
        status.text = if (ready) "● جاهز — صلاحيات الهاتف وجهات الاتصال وسجل المكالمات مفعّلة" else "⚠ فعّل صلاحيات الهاتف وجهات الاتصال وسجل المكالمات لقراءة رقم المتصل"
        status.setTextColor(if (ready) Color.rgb(25, 110, 75) else Color.rgb(170, 90, 20))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatus()
    }

    private fun testVoice() {
        val mode = prefs.getInt("language", 0)
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                val text = when (mode) {
                    1 -> "هناك مكالمة واردة من أحمد"
                    2 -> "Incoming call from Ahmed"
                    else -> "هناك مكالمة واردة من أحمد. Incoming call from Ahmed"
                }
                val locale = if (mode == 2) java.util.Locale.UK else java.util.Locale("ar")
                if (engine.setLanguage(locale) < TextToSpeech.LANG_AVAILABLE) engine.setLanguage(java.util.Locale.getDefault())
                val params = android.os.Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, prefs.getInt("volume", 85) / 100f) }
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, "caller_voice_test")
            } else Toast.makeText(this, "تعذر تشغيل محرك الصوت", Toast.LENGTH_LONG).show()
        }
    }

}
