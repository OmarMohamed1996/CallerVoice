package com.omar.callervoice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import android.telephony.TelephonyManager
import android.media.AudioManager
import android.os.Bundle
import java.util.Locale

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (intent.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return

        val prefs = context.getSharedPreferences("caller_voice", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return

        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER).orEmpty()
        val caller = findContactName(context, number) ?: number.takeIf { it.isNotBlank() } ?: "رقم غير معروف"
        val pending = goAsync()
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context.applicationContext) { result ->
            if (result != TextToSpeech.SUCCESS) {
                pending.finish()
                return@TextToSpeech
            }
            val mode = prefs.getInt("language", 0)
            val repeats = if (prefs.getInt("repeat", 0) == 1) 2 else 1
            val volume = (prefs.getInt("volume", 85).coerceIn(0, 100) / 100f)
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume) }
            speakAnnouncement(engine, caller, mode, repeats, params) { engine.shutdown(); pending.finish() }
        }
    }

    private fun findContactName(context: Context, number: String): String? {
        if (number.isBlank()) return null
        var cursor: Cursor? = null
        return try {
            val uri: Uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            cursor = context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) cursor.getString(0) else null
        } catch (_: Exception) { null }
        finally { cursor?.close() }
    }

    private fun speakAnnouncement(
        tts: TextToSpeech,
        caller: String,
        mode: Int,
        repeats: Int,
        params: Bundle,
        finish: () -> Unit
    ) {
        var remaining = repeats
        var finished = false
        fun finishOnce() {
            if (!finished) { finished = true; finish() }
        }
        lateinit var playCycle: () -> Unit
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onError(utteranceId: String?) { finishOnce() }
            override fun onDone(utteranceId: String?) {
                when {
                    utteranceId == "bilingual_ar" -> {
                        setLanguageOrFallback(tts, Locale.UK)
                        tts.speak("Incoming call from $caller", TextToSpeech.QUEUE_FLUSH, params, "bilingual_en")
                    }
                    utteranceId == "bilingual_en" || utteranceId?.startsWith("single_") == true -> {
                        if (remaining > 0) playCycle() else finishOnce()
                    }
                }
            }
        })
        playCycle = {
            if (finished) Unit else {
            remaining--
            when (mode) {
                1 -> {
                    setLanguageOrFallback(tts, Locale("ar"))
                    tts.speak("مكالمة واردة من $caller", TextToSpeech.QUEUE_FLUSH, params, "single_ar_$remaining")
                }
                2 -> {
                    setLanguageOrFallback(tts, Locale.UK)
                    tts.speak("Incoming call from $caller", TextToSpeech.QUEUE_FLUSH, params, "single_en_$remaining")
                }
                else -> {
                    setLanguageOrFallback(tts, Locale("ar"))
                    tts.speak("مكالمة واردة من $caller", TextToSpeech.QUEUE_FLUSH, params, "bilingual_ar")
                }
            }
        }
        }
        playCycle()
    }

    private fun setLanguageOrFallback(tts: TextToSpeech, locale: Locale) {
        val result = tts.setLanguage(locale)
        if (result < TextToSpeech.LANG_AVAILABLE) tts.setLanguage(Locale.getDefault())
    }
}
